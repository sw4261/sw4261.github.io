#!/bin/bash
git init
git add .
git commit -m "Initial commit: URFT Simulation Archive"
